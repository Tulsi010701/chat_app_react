import React from "react";
import ChatContainer from "./Components/ChatContainer";

const App = () => {
  return (
    <>
      <div
        className="container"
        style={{ backgroundColor: "#edf1f5", maxHeight: "100%", padding: 10 }}
      >
        <ChatContainer />
      </div>
    </>
  );
};

export default App;
