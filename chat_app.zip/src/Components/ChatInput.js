import React, { useState } from "react";
import Picker from "emoji-picker-react";
import "../App.css";

const ChatInput = ({ sendMessage }) => {
  const [inputStr, setInputStr] = useState("");
  const [showPicker, setShowPicker] = useState(false);

  const onEmojiClick = (event, emojiObject) => {
    setInputStr((prevInput) => prevInput + emojiObject.emoji);
    setShowPicker(false);
  };

  const handleInputChange = (event) => {
    setInputStr(event.target.value);
  };

  const handleKeyPress = (event) => {
    if (event.key === "Enter" && inputStr.trim() !== "") {
      sendMessage({ text: inputStr });
      setInputStr("");
    }
  };

  const handleSend = () => {
    if (inputStr.trim() !== "") {
      sendMessage({ text: inputStr });
      setInputStr("");
    }
  };

  return (
    <div className="app1">
      <div className="picker-container">
        {showPicker && (
          <div className="emoji-picker-container">
            <Picker pickerStyle={{ width: "" }} onEmojiClick={onEmojiClick} />
          </div>
        )}
        <input
          className="input-style"
          value={inputStr}
          onChange={handleInputChange}
          onKeyDown={handleKeyPress} 
          placeholder="Write something..."
        />
        <img
          className="emoji-icon"
          src="https://icons.getbootstrap.com/assets/icons/emoji-smile.svg"
          alt="emoji-picker"
          onClick={() => setShowPicker((val) => !val)}
        />
        <button className="send-button" onClick={handleSend}>
          Send
        </button>
      </div>
    </div>
  );
};

export default ChatInput;
