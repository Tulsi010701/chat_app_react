import React from "react";
import ChatMessage from "./ChatMessage";

const ChatContainer = () => {
  return (
    <>
      <ChatMessage />
    </>
  );
};

export default ChatContainer;
