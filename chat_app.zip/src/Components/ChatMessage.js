import React, { useState, useEffect } from "react";
import ChatInput from "./ChatInput";
import socketIOClient from "socket.io-client";

const user_list = ["Alan", "Bob", "Carol", "Dean", "Elin"];

const ChatApp = () => {
  const [messages, setMessages] = useState([]);
  const [socket, setSocket] = useState(null);
  const [userColors, setUserColors] = useState(() => {
    const storedColors = localStorage.getItem("userColors");
    return storedColors ? JSON.parse(storedColors) : {};
  });

  useEffect(() => {
    const newSocket = socketIOClient("http://localhost:5000");
    setSocket(newSocket);

    return () => newSocket.disconnect();
  }, []);

  useEffect(() => {
    localStorage.setItem("userColors", JSON.stringify(userColors));
  }, [userColors]);

  useEffect(() => {
    if (socket) {
      socket.on("chat", (message) => {
        setMessages((prevMessages) => [message, ...prevMessages]);
      });

      socket.on("like", (updatedMessage) => {
        setMessages((prevMessages) => {
          return prevMessages.map((msg) => {
            if (msg.id === updatedMessage.id) {
              return { ...msg, likes: updatedMessage.likes };
            } else {
              return msg;
            }
          });
        });
      });
    }
  }, [socket]);

  const addMessage = (newMessage) => {
    const randomUser = user_list[Math.floor(Math.random() * user_list.length)];
    const timestamp = new Date().toLocaleTimeString();
    newMessage.user = randomUser.charAt(0);
    newMessage.timestamp = timestamp;

    if (!userColors[randomUser]) {
      const color = getRandomColor();
      setUserColors((prevUserColors) => ({
        ...prevUserColors,
        [randomUser]: color,
      }));
      newMessage.color = color;
    } else {
      newMessage.color = userColors[randomUser];
    }

    if (socket) {
      socket.emit("chat", newMessage);
    }
  };

  const handleLike = (id) => {
    setMessages((prevMessages) =>
      prevMessages.map((msg) => {
        if (msg.id === id) {
          return { ...msg, likes: (msg.likes || 0) + 1 };
        } else {
          return msg;
        }
      })
    );

    if (socket) {
      socket.emit("like", id);
    }
  };

  return (
    <div className="app">
      <div>
        {messages
          .slice()
          .reverse()
          .map((msg) => (
            <div key={msg.id}>
              <div style={{ display: "flex", alignItems: "center" }}>
                <p
                  className="msg-user"
                  style={{
                    backgroundColor: msg.color || getRandomColor(),
                  }}
                >
                  {msg.user}
                </p>
                <span style={{ marginLeft: "10px", fontSize: "12px" }}>
                  {msg.timestamp}
                </span>
              </div>{" "}
              <div className="msg-content">
                <p className="msg-text">{msg.text}</p>
                <button onClick={() => handleLike(msg.id)} className="like-btn">
                  <i className="fa fa-thumbs-up" aria-hidden="true"></i>
                  {msg.likes || ""}
                </button>
              </div>
            </div>
          ))}
      </div>
      <ChatInput sendMessage={addMessage} />
    </div>
  );
};

export default ChatApp;

const getRandomColor = () => {
  return "#" + Math.floor(Math.random() * 16777215).toString(16);
};
